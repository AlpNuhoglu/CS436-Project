def handler(event, context):
    email = event.get("request", {}).get("userAttributes", {}).get("email", "")
    if not email.lower().endswith("@sabanciuniv.edu"):
        raise Exception("Only @sabanciuniv.edu email addresses are allowed.")
    event["response"]["autoConfirmUser"] = False
    event["response"]["autoVerifyEmail"] = False
    return event
